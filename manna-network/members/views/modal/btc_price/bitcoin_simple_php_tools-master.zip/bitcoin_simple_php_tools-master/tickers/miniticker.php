<?php
//require_once ( dirname(__FILE__) . "/../lib/mtgoxrate.php");
require_once ( dirname(__FILE__) . "/../lib/cachemtgoxrate.php");

echo cachemtGoxRate();


?>

