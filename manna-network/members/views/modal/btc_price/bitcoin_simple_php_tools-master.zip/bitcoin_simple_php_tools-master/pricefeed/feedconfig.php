<?php

$providedbyurl="http://bitcoin.gw.gd";
$feeddescription="RSS feed providing the latest bitcoin price, from mtgox API, provided by ".$providedbyurl;
$donations="free service provided by : ".$providedbyurl." , donations welcome : 1va4sqj5AFnMYicD7JzhDfxauk5w6Uuug";
//$feedownurl="http://p.b.gw.gd/pricefeed/bitcoin_price_feed.php";

?>
