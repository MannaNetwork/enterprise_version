<!DOCTYPE html>
<html>
<head>
<title>My Report</title>
    <meta charset="utf-8">
<? include "addbslocal.php" ?>
</head>
<body>
<?
	include_once("phpBSReports.php");
	$rpt = new phpReport();
  $rpt->width = "95%";
	$rpt->header_color = "#4477ff";
	$rpt->header_textcolor="#ffffff";
  $rpt->header_alignment="center";
	$rpt->body_alignment = "left";
	$rpt->body_color = "#ffeeee";
	$rpt->body_textcolor = "#991199";
  $rpt->covered_color="#449999";
	$rpt->covered = '1';
  $rpt->striped='1';
  $rpt->bordered='1';
  $rpt->hover='1';
  $rpt->responsive='0';
  $rpt->inverse='1';
  $rpt->condensed='1';
	$rpt->title = "SMS Groups";
  $rpt->footer="Generated on :".date("d-M-Y");

$con = mysqli_connect("localhost","my_user","my_password","my_db");
//use above code with your database details or include connection file db2.php 
//change its values to match your database

//include "db2.php"; //code which makes mysqli connection

include "addjqlocal.php";
echo '<div class="firstdiv" align="center">';
	$res = mysqli_query($con,"select * from msgq");
	$rpt->mysqli_res = $res;
	$rpt->showReport();
	?>
</div>
</body>
</html>